# Own Node harness pilot

| Policy | Outcome | Cost | Complete | Attempts |
|---|---|---:|---|---:|
| Generic (openai/gpt-5.6-luna) | unresolved | $0.046498 | true | 1 |
| Pareto (frozen nine rung) | unresolved | $0.236988 | true | 9 |

Task: `content-type-quoted-parameters`; test: `node --test test/content-type.test.js`.
