export async function retry(operation, { attempts = 3, delay = () => Promise.resolve(), signal } = {}) {
  let lastError;
  for (let attempt = 1; attempt <= attempts; attempt += 1) {
    if (signal?.aborted) throw signal.reason;
    try {
      return await operation(attempt);
    } catch (error) {
      lastError = error;
      if (attempt < attempts) {
        if (signal?.aborted) throw signal.reason;
        let removeAbortListener;
        try {
          const cancelled = signal && new Promise((_, reject) => {
            const onAbort = () => reject(signal.reason);
            signal.addEventListener("abort", onAbort, { once: true });
            removeAbortListener = () => signal.removeEventListener("abort", onAbort);
          });
          await Promise.race([delay(attempt), cancelled]);
        } finally {
          removeAbortListener?.();
        }
      }
    }
  }
  throw lastError;
}
