export function buildUrl(path, query) {
  const params = new URLSearchParams();

  for (const [key, value] of Object.entries(query)) {
    if (Array.isArray(value) && value.length > 0) {
      for (const v of value) {
        params.append(key, v);
      }
    } else if (value !== null && value !== undefined) {
      params.set(key, value);
    }
  }

  const suffix = params.toString();
  return suffix ? `${path}?${suffix}` : path;
}
