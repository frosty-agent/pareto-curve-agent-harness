# Own Node harness pilot

| Policy | Outcome | Cost | Complete | Attempts |
|---|---|---:|---|---:|
| Generic (openai/gpt-5.6-luna) | unresolved | $0.026017 | true | 1 |
| Pareto (frozen nine rung) | unresolved | $0.195514 | true | 9 |

Task: `secure-static-path-resolution`; test: `node --test test/static-path.test.js`.
