export function createRequest(body) {
  return {
    headers: {
      "content-length": String(Buffer.byteLength(body, "utf8")),
    },
    body,
  };
}
