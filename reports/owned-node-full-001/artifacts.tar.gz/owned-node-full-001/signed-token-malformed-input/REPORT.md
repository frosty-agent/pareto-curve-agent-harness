# Own Node harness pilot

| Policy | Outcome | Cost | Complete | Attempts |
|---|---|---:|---|---:|
| Generic (openai/gpt-5.6-luna) | unresolved | $0.020511 | true | 1 |
| Pareto (frozen nine rung) | resolved | $0.058192 | true | 6 |

Task: `signed-token-malformed-input`; test: `node --test test/token.test.js`.
