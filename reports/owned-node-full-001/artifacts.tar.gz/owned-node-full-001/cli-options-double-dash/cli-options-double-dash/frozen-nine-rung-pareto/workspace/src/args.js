export function parseArgs(tokens) {
  const options = {};
  const positionals = [];
  let doubleDashIndex = -1;

  for (const token of tokens) {
    if (token === "--") {
      doubleDashIndex = tokens.indexOf(token);
      break;
    }
    if (token.startsWith("--")) {
      options[token.slice(2)] = true;
    } else if (token.startsWith("-")) {
      options[token.slice(1)] = true;
    } else {
      positionals.push(token);
    }
  }
  if (doubleDashIndex !== -1) {
    positionals.push(...tokens.slice(doubleDashIndex + 1));
  }

  return { options, positionals };
}
